#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include "arvoreb.h"
#include "arvoreUtils.h"

void menu() {
    printf("\n--- MENU ARVORE B ---");
    printf("\n1. Cadastrar");
    printf("\n2. Pesquisar");
    printf("\n3. Gravar");
    printf("\n4. Sair");
    printf("\nOpcao: ");
}

// Alteração aqui: adicionamos int argc e char* argv[]
int main(int argc, char* argv[]) {
    
    // Verifica se o usuário passou a quantidade correta de argumentos
    if (argc != 3) {
        printf("Erro nos parametros!\n");
        printf("Uso correto: %s <arquivo_registros> <arquivo_saida_arvore>\n", argv[0]);
        return 1;
    }

    // Mapeia os argumentos passados para variáveis com nomes legíveis
    char* arquivo_registros = argv[1];
    char* arquivo_saida_arvore = argv[2];

    // Carrega a árvore usando o primeiro arquivo passado
    btree* root = load_tree_from_txt(arquivo_registros);
    int opcao = 0;

    if (root == NULL) {
        printf("Erro ao inicializar a árvore.\n");
        return 1;
    }

    while (opcao != 4) {
        menu();
        if (scanf("%d", &opcao) != 1) {
            while(getchar() != '\n'); 
            continue;
        }

        if (opcao == 1) { 
            int mat;
            char nome[50], tel[20];
            int valido;

            printf("Matricula: "); scanf("%d", &mat);

            if (search_node(root, mat) != NULL) {
              printf("Erro: Matricula já cadastrada!\n");
              continue;
            }

            do {
                printf("Nome: "); 
                scanf(" %[^\n]", nome);
                
                valido = 1; 
                for (int i = 0; nome[i] != '\0'; i++) {
                    if (!isalpha(nome[i]) && !isspace(nome[i])) {
                        valido = 0;
                        printf("Nome invalido! Nao use numeros ou caracteres especiais.\n");
                        break; 
                    }
                }
            } while (!valido);

            do {
                printf("Telefone: "); 
                scanf(" %[^\n]", tel);
                
                valido = 1;
                for (int i = 0; tel[i] != '\0'; i++) {
                    if (!isdigit(tel[i])) {
                        valido = 0;
                        printf("Telefone invalido! Digite apenas numeros.\n");
                        break; 
                    }
                }
            } while (!valido);

            // Abre o arquivo passado por parâmetro
            FILE* f = fopen(arquivo_registros, "r+");
            if (f == NULL) {
                f = fopen(arquivo_registros, "w+");
            }
            
            if (f != NULL) {
                fseek(f, 0, SEEK_END);
                long fileSize = ftell(f);
                
                if (fileSize > 0) {
                    fseek(f, -1, SEEK_END);
                    int lastChar = fgetc(f);
                    if (lastChar != '\n') {
                        fprintf(f, "\n"); 
                    }
                }

                fseek(f, 0, SEEK_END);
                long offset = ftell(f); 
                
                fprintf(f, "%d;%s;%s\n", mat, nome, tel);
                fclose(f);

                Registro reg = {mat, offset};
                insert(&root, reg); 
                printf("Registro cadastrado com sucesso!\n");
            } else {
                printf("Erro ao abrir arquivo para escrita.\n");
            }
        } 
        else if (opcao == 2) { 
            int mat;
            printf("Matricula para pesquisa: "); scanf("%d", &mat);
            Registro* r = search_node(root, mat);
            
            if (r) {
                // Abre o arquivo passado por parâmetro
                FILE* f = fopen(arquivo_registros, "r");
                if (f != NULL) {
                    fseek(f, r->byte_offset, SEEK_SET); 
                    char buffer[256];
                    if (fgets(buffer, sizeof(buffer), f)) {
                        buffer[strcspn(buffer, "\n")] = 0;
                        printf("Dados encontrados: %s\n", buffer);
                    }
                    fclose(f);
                }
            } else {
                printf("Matricula %d nao encontrada.\n", mat);
            }
        } 
        else if (opcao == 3) { 
            // Grava no segundo arquivo passado por parâmetro
            if (save_tree_to_txt(root, arquivo_saida_arvore)) {
                printf("Estrutura da arvore gravada em '%s'!\n", arquivo_saida_arvore);
            } else {
                printf("Erro ao gravar a arvore.\n");
            }
        }
    }

    free_tree(root); 
    printf("Sistema encerrado e memoria liberada.\n");
    
    return 0;
}